/**
 * CORS Helper for Quotation Generation Service
 * Provides consistent CORS headers across all endpoints
 */
import { HttpRequest, HttpResponseInit } from '@azure/functions';
/**
 * Get CORS headers for a given request
 */
export declare function getCorsHeaders(request: HttpRequest): Record<string, string>;
/**
 * Handle OPTIONS preflight request
 */
export declare function handlePreflight(request: HttpRequest): HttpResponseInit | null;
/**
 * Add CORS headers to response
 */
export declare function withCors(request: HttpRequest, response: HttpResponseInit): HttpResponseInit;
