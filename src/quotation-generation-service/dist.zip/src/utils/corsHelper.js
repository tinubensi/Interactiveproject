"use strict";
/**
 * CORS Helper for Quotation Generation Service
 * Provides consistent CORS headers across all endpoints
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCorsHeaders = getCorsHeaders;
exports.handlePreflight = handlePreflight;
exports.withCors = withCors;
const ALLOWED_ORIGINS = [
    'http://localhost:3000',
    'http://localhost:3001',
    'https://localhost:3000',
    'https://localhost:3001',
    // Add production domains here when deployed
];
/**
 * Get CORS headers for a given request
 */
function getCorsHeaders(request) {
    const origin = request.headers.get('origin') || '';
    // Allow all origins in development
    const allowedOrigin = origin || '*';
    return {
        'Access-Control-Allow-Origin': allowedOrigin,
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-ms-client-request-id',
        'Access-Control-Max-Age': '86400',
    };
}
/**
 * Handle OPTIONS preflight request
 */
function handlePreflight(request) {
    if (request.method === 'OPTIONS') {
        return {
            status: 204,
            headers: getCorsHeaders(request),
        };
    }
    return null;
}
/**
 * Add CORS headers to response
 */
function withCors(request, response) {
    return {
        ...response,
        headers: {
            ...response.headers,
            ...getCorsHeaders(request),
        },
    };
}
//# sourceMappingURL=corsHelper.js.map