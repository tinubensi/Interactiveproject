"use strict";
/**
 * Cosmos DB Service for Quotation Generation
 * Handles all database operations for plans, filters, comparisons
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.cosmosService = void 0;
const cosmos_1 = require("@azure/cosmos");
class CosmosService {
    client;
    database;
    fetchRequestsContainer;
    plansContainer;
    planFiltersContainer;
    planComparisonsContainer;
    vendorsContainer;
    constructor() {
        // Support both connection string (Azure) and separate endpoint/key (emulator)
        const connectionString = process.env.COSMOS_CONNECTION_STRING;
        const endpoint = process.env.COSMOS_DB_ENDPOINT;
        const key = process.env.COSMOS_DB_KEY;
        const databaseName = process.env.COSMOS_DB_NAME || 'quotation-generation-service-db';
        if (connectionString) {
            // Using Azure Cosmos DB (production/cloud)
            this.client = new cosmos_1.CosmosClient(connectionString);
        }
        else if (endpoint && key) {
            // Using emulator with separate endpoint/key
            if (endpoint && (endpoint.includes('localhost') || endpoint.includes('127.0.0.1'))) {
                process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
            }
            this.client = new cosmos_1.CosmosClient({ endpoint, key });
        }
        else {
            throw new Error('COSMOS_CONNECTION_STRING or (COSMOS_DB_ENDPOINT + COSMOS_DB_KEY) must be set');
        }
        this.database = this.client.database(databaseName);
        this.fetchRequestsContainer = this.database.container('fetchRequests');
        this.plansContainer = this.database.container('plans');
        this.planFiltersContainer = this.database.container('planFilters');
        this.planComparisonsContainer = this.database.container('planComparisons');
        this.vendorsContainer = this.database.container('vendors');
    }
    async initialize() {
        try {
            await this.client.databases.createIfNotExists({ id: process.env.COSMOS_DB_NAME || 'quotation-generation-service-db' });
            await this.database.containers.createIfNotExists({
                id: 'fetchRequests',
                partitionKey: { paths: ['/leadId'] }
            });
            await this.database.containers.createIfNotExists({
                id: 'plans',
                partitionKey: { paths: ['/leadId'] },
                indexingPolicy: {
                    indexingMode: 'consistent',
                    automatic: true,
                    includedPaths: [{ path: '/*' }],
                    compositeIndexes: [
                        [
                            { path: '/leadId', order: 'ascending' },
                            { path: '/annualPremium', order: 'ascending' }
                        ]
                    ]
                }
            });
            await this.database.containers.createIfNotExists({
                id: 'planFilters',
                partitionKey: { paths: ['/leadId'] }
            });
            await this.database.containers.createIfNotExists({
                id: 'planComparisons',
                partitionKey: { paths: ['/leadId'] }
            });
            await this.database.containers.createIfNotExists({
                id: 'vendors',
                partitionKey: { paths: ['/lineOfBusiness'] }
            });
            console.log('PlanDB initialized successfully');
        }
        catch (error) {
            console.error('Error initializing Cosmos DB:', error);
            throw error;
        }
    }
    // ==================== FETCH REQUESTS ====================
    async createFetchRequest(request) {
        const { resource } = await this.fetchRequestsContainer.items.create(request);
        return resource;
    }
    async getFetchRequest(id, leadId) {
        try {
            const { resource } = await this.fetchRequestsContainer.item(id, leadId).read();
            return resource || null;
        }
        catch (error) {
            if (error.code === 404)
                return null;
            throw error;
        }
    }
    async updateFetchRequest(id, leadId, updates) {
        const existing = await this.getFetchRequest(id, leadId);
        if (!existing)
            throw new Error('Fetch request not found');
        const updated = { ...existing, ...updates };
        const { resource } = await this.fetchRequestsContainer.item(id, leadId).replace(updated);
        return resource;
    }
    // ==================== PLANS ====================
    async createPlan(plan) {
        const { resource } = await this.plansContainer.items.create(plan);
        return resource;
    }
    async createPlans(plans) {
        const promises = plans.map(plan => this.createPlan(plan));
        return Promise.all(promises);
    }
    async getPlanById(id, leadId) {
        try {
            const { resource } = await this.plansContainer.item(id, leadId).read();
            return resource || null;
        }
        catch (error) {
            if (error.code === 404)
                return null;
            throw error;
        }
    }
    async getPlansForLead(leadId) {
        const query = {
            query: 'SELECT * FROM c WHERE c.leadId = @leadId ORDER BY c.annualPremium ASC',
            parameters: [{ name: '@leadId', value: leadId }]
        };
        const { resources } = await this.plansContainer.items.query(query).fetchAll();
        return resources;
    }
    async listPlans(request) {
        const { leadId, page = 1, limit = 20, sortBy = 'annualPremium', sortOrder = 'asc', filters = {} } = request;
        // Build query
        const conditions = ['c.leadId = @leadId'];
        const parameters = [{ name: '@leadId', value: leadId }];
        let paramIndex = 0;
        if (filters.isAvailable !== undefined) {
            conditions.push(`c.isAvailable = @isAvailable${paramIndex}`);
            parameters.push({ name: `@isAvailable${paramIndex}`, value: filters.isAvailable });
            paramIndex++;
        }
        if (filters.vendorIds && filters.vendorIds.length > 0) {
            conditions.push(`ARRAY_CONTAINS(@vendorIds${paramIndex}, c.vendorId)`);
            parameters.push({ name: `@vendorIds${paramIndex}`, value: filters.vendorIds });
            paramIndex++;
        }
        if (filters.annualPremium) {
            if (filters.annualPremium.min !== undefined) {
                conditions.push(`c.annualPremium >= @premiumMin${paramIndex}`);
                parameters.push({ name: `@premiumMin${paramIndex}`, value: filters.annualPremium.min });
                paramIndex++;
            }
            if (filters.annualPremium.max !== undefined) {
                conditions.push(`c.annualPremium <= @premiumMax${paramIndex}`);
                parameters.push({ name: `@premiumMax${paramIndex}`, value: filters.annualPremium.max });
                paramIndex++;
            }
        }
        const whereClause = `WHERE ${conditions.join(' AND ')}`;
        const orderDirection = sortOrder === 'asc' ? 'ASC' : 'DESC';
        const orderByClause = `ORDER BY c.${sortBy} ${orderDirection}`;
        // Count query
        const countQuery = {
            query: `SELECT VALUE COUNT(1) FROM c ${whereClause}`,
            parameters
        };
        const { resources: countResult } = await this.plansContainer.items.query(countQuery).fetchAll();
        const totalRecords = countResult[0] || 0;
        // Data query
        const offset = (page - 1) * limit;
        const dataQuery = {
            query: `SELECT * FROM c ${whereClause} ${orderByClause} OFFSET ${offset} LIMIT ${limit}`,
            parameters
        };
        const { resources: plans } = await this.plansContainer.items.query(dataQuery).fetchAll();
        const totalPages = Math.ceil(totalRecords / limit);
        return {
            data: plans,
            pagination: {
                page,
                limit,
                totalRecords,
                totalPages,
                hasNext: page < totalPages,
                hasPrevious: page > 1
            },
            filters: {
                applied: filters,
                available: await this.getAvailableFilters(leadId)
            },
            sort: { sortBy, sortOrder }
        };
    }
    async getAvailableFilters(leadId) {
        const plans = await this.getPlansForLead(leadId);
        const vendors = Array.from(new Set(plans.map(p => p.vendorId))).map(vendorId => {
            const vendorPlans = plans.filter(p => p.vendorId === vendorId);
            return {
                id: vendorId,
                name: vendorPlans[0].vendorName,
                count: vendorPlans.length,
                avgPremium: vendorPlans.reduce((sum, p) => sum + p.annualPremium, 0) / vendorPlans.length
            };
        });
        const premiums = plans.map(p => p.annualPremium);
        return {
            vendors,
            planTypes: [],
            priceRanges: {
                minPremium: Math.min(...premiums),
                maxPremium: Math.max(...premiums),
                avgPremium: premiums.reduce((a, b) => a + b, 0) / premiums.length
            },
            coverageRanges: {
                minAnnualLimit: Math.min(...plans.map(p => p.annualLimit)),
                maxAnnualLimit: Math.max(...plans.map(p => p.annualLimit)),
                minDeductible: Math.min(...plans.map(p => p.deductible)),
                maxDeductible: Math.max(...plans.map(p => p.deductible))
            }
        };
    }
    async deletePlansForLead(leadId) {
        const plans = await this.getPlansForLead(leadId);
        for (const plan of plans) {
            try {
                await this.plansContainer.item(plan.id, leadId).delete();
            }
            catch (error) {
                console.error(`Error deleting plan ${plan.id}:`, error);
            }
        }
    }
    async updatePlan(id, leadId, updates) {
        const existing = await this.getPlanById(id, leadId);
        if (!existing)
            throw new Error('Plan not found');
        const updated = { ...existing, ...updates };
        const { resource } = await this.plansContainer.item(id, leadId).replace(updated);
        return resource;
    }
    async selectPlans(leadId, planIds) {
        // First, unselect all plans for this lead
        const allPlans = await this.getPlansForLead(leadId);
        for (const plan of allPlans) {
            if (plan.isSelected) {
                await this.updatePlan(plan.id, leadId, { isSelected: false });
            }
        }
        // Select specified plans
        const selectedPlans = [];
        for (const planId of planIds) {
            const plan = await this.updatePlan(planId, leadId, { isSelected: true });
            selectedPlans.push(plan);
        }
        return selectedPlans;
    }
    // ==================== FILTERS ====================
    async saveFilter(filter) {
        const { resource } = await this.planFiltersContainer.items.upsert(filter);
        return resource;
    }
    async getFilter(leadId) {
        const query = {
            query: 'SELECT * FROM c WHERE c.leadId = @leadId',
            parameters: [{ name: '@leadId', value: leadId }]
        };
        const { resources } = await this.planFiltersContainer.items.query(query).fetchAll();
        return resources.length > 0 ? resources[0] : null;
    }
    async deleteFilter(id, leadId) {
        await this.planFiltersContainer.item(id, leadId).delete();
    }
    // ==================== COMPARISONS ====================
    async createComparison(comparison) {
        const { resource } = await this.planComparisonsContainer.items.create(comparison);
        return resource;
    }
    async getComparison(id, leadId) {
        try {
            const { resource } = await this.planComparisonsContainer.item(id, leadId).read();
            return resource || null;
        }
        catch (error) {
            if (error.code === 404)
                return null;
            throw error;
        }
    }
    async getComparisonForLead(leadId) {
        const query = {
            query: 'SELECT * FROM c WHERE c.leadId = @leadId ORDER BY c.createdAt DESC',
            parameters: [{ name: '@leadId', value: leadId }]
        };
        const { resources } = await this.planComparisonsContainer.items.query(query).fetchAll();
        return resources[0] || null;
    }
    // ==================== VENDORS ====================
    async createVendor(vendor) {
        const { resource } = await this.vendorsContainer.items.create(vendor);
        return resource;
    }
    async getVendorsByLOB(lineOfBusiness) {
        const query = {
            query: 'SELECT * FROM c WHERE c.lineOfBusiness = @lob AND c.isActive = true ORDER BY c.priority ASC',
            parameters: [{ name: '@lob', value: lineOfBusiness }]
        };
        const { resources } = await this.vendorsContainer.items.query(query).fetchAll();
        return resources;
    }
    async getAllVendors() {
        const query = 'SELECT * FROM c WHERE c.isActive = true ORDER BY c.priority ASC';
        const { resources } = await this.vendorsContainer.items.query(query).fetchAll();
        return resources;
    }
    async seedVendors(vendors) {
        for (const vendor of vendors) {
            await this.vendorsContainer.items.upsert({
                ...vendor,
                createdAt: new Date(),
                updatedAt: new Date()
            });
        }
    }
}
exports.cosmosService = new CosmosService();
//# sourceMappingURL=cosmosService.js.map