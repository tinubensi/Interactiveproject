/**
 * Event Grid Service for Quotation Generation
 */
import { LineOfBusiness } from '../models/plan';
declare class EventGridService {
    private client;
    private topicEndpoint;
    constructor();
    publishEvent(eventType: string, subject: string, data: any, dataVersion?: string): Promise<void>;
    publishPlansFetchStarted(data: {
        leadId: string;
        fetchRequestId: string;
        lineOfBusiness: LineOfBusiness;
        vendorCount: number;
    }): Promise<void>;
    publishPlansFetchCompleted(data: {
        leadId: string;
        fetchRequestId: string;
        totalPlans: number;
        successfulVendors: string[];
        failedVendors: string[];
        plans: any[];
    }): Promise<void>;
    publishPlansFetchFailed(data: {
        leadId: string;
        fetchRequestId: string;
        error: string;
    }): Promise<void>;
    publishPlansFiltered(data: {
        leadId: string;
        filterCriteria: any;
        resultCount: number;
    }): Promise<void>;
    publishPlansCompared(data: {
        leadId: string;
        comparisonId: string;
        planIds: string[];
    }): Promise<void>;
    publishPlansSelected(data: {
        leadId: string;
        planIds: string[];
        selectedBy?: string;
    }): Promise<void>;
}
export declare const eventGridService: EventGridService;
export {};
