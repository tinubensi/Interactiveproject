/**
 * Plan Fetching Service
 * Fetches insurance plans from vendors (static for now, RPA later)
 * Reference: Petli getPlans logic
 */
import { Plan, LineOfBusiness, Vendor } from '../models/plan';
declare class PlanFetchingService {
    /**
     * Fetch plans for a lead from all available vendors
     * Currently uses static data, will integrate with RPA APIs in future
     */
    fetchPlansForLead(params: {
        leadId: string;
        lineOfBusiness: LineOfBusiness;
        businessType: string;
        leadData: any;
        fetchRequestId: string;
    }): Promise<{
        plans: Plan[];
        successfulVendors: string[];
        failedVendors: string[];
    }>;
    /**
     * Future: Fetch plans from RPA API
     */
    fetchPlansFromRPA(vendor: Vendor, leadData: any): Promise<Plan[]>;
    /**
     * Calculate recommended plan based on criteria
     */
    calculateRecommendedPlan(plans: Plan[]): Plan | null;
}
export declare const planFetchingService: PlanFetchingService;
export {};
