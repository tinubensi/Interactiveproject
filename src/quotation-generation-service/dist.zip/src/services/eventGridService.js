"use strict";
/**
 * Event Grid Service for Quotation Generation
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventGridService = void 0;
const eventgrid_1 = require("@azure/eventgrid");
const uuid_1 = require("uuid");
class EventGridService {
    client;
    topicEndpoint;
    constructor() {
        this.topicEndpoint = process.env.EVENT_GRID_TOPIC_ENDPOINT;
        const topicKey = process.env.EVENT_GRID_TOPIC_KEY;
        this.client = new eventgrid_1.EventGridPublisherClient(this.topicEndpoint, 'EventGrid', new eventgrid_1.AzureKeyCredential(topicKey), {
            allowInsecureConnection: true // Allow HTTP connections for local Event Grid mock
        });
    }
    async publishEvent(eventType, subject, data, dataVersion = '1.0') {
        try {
            const event = {
                id: (0, uuid_1.v4)(),
                eventType,
                subject,
                eventTime: new Date().toISOString(),
                data,
                dataVersion
            };
            await this.client.send([event]);
            console.log(`Event published: ${eventType}`);
        }
        catch (error) {
            console.error(`Failed to publish event ${eventType}:`, error);
            throw error;
        }
    }
    // ==================== SPECIFIC EVENTS ====================
    async publishPlansFetchStarted(data) {
        await this.publishEvent('plans.fetch_started', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansFetchCompleted(data) {
        await this.publishEvent('plans.fetch_completed', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansFetchFailed(data) {
        await this.publishEvent('plans.fetch_failed', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansFiltered(data) {
        await this.publishEvent('plans.filtered', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansCompared(data) {
        await this.publishEvent('plans.compared', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansSelected(data) {
        await this.publishEvent('plans.selected', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
}
exports.eventGridService = new EventGridService();
//# sourceMappingURL=eventGridService.js.map