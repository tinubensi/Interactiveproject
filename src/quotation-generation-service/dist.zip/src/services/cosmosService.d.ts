/**
 * Cosmos DB Service for Quotation Generation
 * Handles all database operations for plans, filters, comparisons
 */
import { Plan, PlanFetchRequest, PlanFilter, PlanComparison, Vendor, PlanListRequest, PlanListResponse } from '../models/plan';
declare class CosmosService {
    private client;
    private database;
    private fetchRequestsContainer;
    private plansContainer;
    private planFiltersContainer;
    private planComparisonsContainer;
    private vendorsContainer;
    constructor();
    initialize(): Promise<void>;
    createFetchRequest(request: PlanFetchRequest): Promise<PlanFetchRequest>;
    getFetchRequest(id: string, leadId: string): Promise<PlanFetchRequest | null>;
    updateFetchRequest(id: string, leadId: string, updates: Partial<PlanFetchRequest>): Promise<PlanFetchRequest>;
    createPlan(plan: Plan): Promise<Plan>;
    createPlans(plans: Plan[]): Promise<Plan[]>;
    getPlanById(id: string, leadId: string): Promise<Plan | null>;
    getPlansForLead(leadId: string): Promise<Plan[]>;
    listPlans(request: PlanListRequest): Promise<PlanListResponse>;
    private getAvailableFilters;
    deletePlansForLead(leadId: string): Promise<void>;
    updatePlan(id: string, leadId: string, updates: Partial<Plan>): Promise<Plan>;
    selectPlans(leadId: string, planIds: string[]): Promise<Plan[]>;
    saveFilter(filter: PlanFilter): Promise<PlanFilter>;
    getFilter(leadId: string): Promise<PlanFilter | null>;
    deleteFilter(id: string, leadId: string): Promise<void>;
    createComparison(comparison: PlanComparison): Promise<PlanComparison>;
    getComparison(id: string, leadId: string): Promise<PlanComparison | null>;
    getComparisonForLead(leadId: string): Promise<PlanComparison | null>;
    createVendor(vendor: Vendor): Promise<Vendor>;
    getVendorsByLOB(lineOfBusiness: string): Promise<Vendor[]>;
    getAllVendors(): Promise<Vendor[]>;
    seedVendors(vendors: Omit<Vendor, 'createdAt' | 'updatedAt'>[]): Promise<void>;
}
export declare const cosmosService: CosmosService;
export {};
