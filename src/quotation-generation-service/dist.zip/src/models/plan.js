"use strict";
/**
 * Plan Models
 * Reference: Petli plan.js model
 * Designed to work with all LOBs (Medical, Motor, General, Marine)
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=plan.js.map