/**
 * Plan Models
 * Reference: Petli plan.js model
 * Designed to work with all LOBs (Medical, Motor, General, Marine)
 */
export type LineOfBusiness = 'medical' | 'motor' | 'general' | 'marine';
export type PlanSource = 'static' | 'rpa' | 'api';
/**
 * Premium Item - Individual item (member, vehicle, property) in a plan
 * Used for member-wise, vehicle-wise premium breakdown
 */
export interface PremiumItem {
    itemId: string;
    itemType: string;
    itemName: string;
    itemDetails: any;
    isPrimary: boolean;
    annualPremium: number;
    monthlyPremium: number;
}
/**
 * LOB Specific Data structure
 */
export interface LobSpecificData {
    networkProviders?: string;
    areaOfCover?: string;
    copayTestMedicine?: string;
    copayConsultation?: string;
    premiumItems?: PremiumItem[];
    itemCount?: number;
    basePremiumPerItem?: number;
    [key: string]: any;
}
/**
 * Plan Model - Core insurance plan
 */
export interface Plan {
    id: string;
    leadId: string;
    vendorId: string;
    vendorName: string;
    vendorCode: string;
    planName: string;
    planCode: string;
    planType: string;
    annualPremium: number;
    monthlyPremium: number;
    currency: string;
    annualLimit: number;
    deductible: number;
    deductibleMetric?: string;
    coInsurance: number;
    coInsuranceMetric?: string;
    waitingPeriod: number;
    waitingPeriodMetric?: string;
    benefits: BenefitCategory[];
    exclusions: string[];
    addons?: Addon[];
    lineOfBusiness: LineOfBusiness;
    lobSpecificData?: LobSpecificData;
    isAvailable: boolean;
    isSelected: boolean;
    isRecommended: boolean;
    fetchRequestId: string;
    fetchedAt: Date;
    source: PlanSource;
    quotationId?: string;
    rawPlanData?: any;
}
/**
 * Benefit Category
 */
export interface BenefitCategory {
    categoryId: string;
    categoryName: string;
    benefits: BenefitDetail[];
}
/**
 * Benefit Detail
 */
export interface BenefitDetail {
    benefitId?: string;
    name: string;
    covered: boolean;
    limit?: number;
    limitMetric?: string;
    description?: string;
    subBenefits?: BenefitDetail[];
}
/**
 * Plan Addon
 */
export interface Addon {
    addonId: string;
    name: string;
    description: string;
    additionalPremium: number;
    benefits: BenefitDetail[];
}
/**
 * Plan Fetch Request
 * Tracks the process of fetching plans for a lead
 */
export interface PlanFetchRequest {
    id: string;
    leadId: string;
    lineOfBusiness: LineOfBusiness;
    businessType: string;
    leadData: any;
    status: 'pending' | 'fetching' | 'completed' | 'failed';
    totalVendors: number;
    successfulVendors: string[];
    failedVendors: string[];
    unavailableVendors: string[];
    totalPlansFound: number;
    errors?: Array<{
        vendorId: string;
        vendorName: string;
        error: string;
        timestamp: Date;
    }>;
    createdAt: Date;
    startedAt?: Date;
    completedAt?: Date;
}
/**
 * Plan Filter
 * User-defined filter criteria
 */
export interface PlanFilter {
    id: string;
    leadId: string;
    annualPremium?: {
        min?: number;
        max?: number;
    };
    monthlyPremium?: {
        min?: number;
        max?: number;
    };
    annualLimit?: {
        min?: number;
        max?: number;
    };
    deductible?: {
        min?: number;
        max?: number;
    };
    coInsurance?: {
        min?: number;
        max?: number;
    };
    waitingPeriod?: {
        min?: number;
        max?: number;
    };
    selectedVendors?: string[];
    excludedVendors?: string[];
    planTypes?: string[];
    requiredBenefits?: string[];
    excludedBenefits?: string[];
    createdAt: Date;
    updatedAt: Date;
}
/**
 * Plan Comparison
 * Side-by-side comparison of selected plans
 */
export interface PlanComparison {
    id: string;
    leadId: string;
    planIds: string[];
    comparisonMatrix: ComparisonRow[];
    createdAt: Date;
}
/**
 * Comparison Row
 */
export interface ComparisonRow {
    feature: string;
    category: string;
    plans: Record<string, any>;
}
/**
 * Vendor Model
 */
export interface Vendor {
    id: string;
    name: string;
    code: string;
    lineOfBusiness: LineOfBusiness;
    logo?: string;
    website?: string;
    rpaEnabled: boolean;
    rpaEndpoint?: string;
    rpaApiKey?: string;
    rpaConfig?: any;
    hasStaticPlans: boolean;
    isActive: boolean;
    priority: number;
    createdAt: Date;
    updatedAt: Date;
}
/**
 * Plan List Request DTO
 */
export interface PlanListRequest {
    leadId: string;
    page: number;
    limit: number;
    sortBy?: 'annualPremium' | 'monthlyPremium' | 'deductible' | 'annualLimit' | 'coInsurance' | 'waitingPeriod';
    sortOrder?: 'asc' | 'desc';
    applyFilterId?: string;
    filters?: {
        vendorIds?: string[];
        isAvailable?: boolean;
        isSelected?: boolean;
        planTypes?: string[];
        annualPremium?: {
            min?: number;
            max?: number;
        };
        monthlyPremium?: {
            min?: number;
            max?: number;
        };
        annualLimit?: {
            min?: number;
            max?: number;
        };
        deductible?: {
            min?: number;
            max?: number;
        };
        coInsurance?: {
            min?: number;
            max?: number;
        };
        waitingPeriod?: {
            min?: number;
            max?: number;
        };
    };
}
/**
 * Plan List Response DTO
 */
export interface PlanListResponse {
    data: Plan[];
    pagination: {
        page: number;
        limit: number;
        totalRecords: number;
        totalPages: number;
        hasNext: boolean;
        hasPrevious: boolean;
    };
    filters: {
        applied: any;
        available: {
            vendors: Array<{
                id: string;
                name: string;
                count: number;
                avgPremium: number;
            }>;
            planTypes: Array<{
                value: string;
                label: string;
                count: number;
            }>;
            priceRanges: {
                minPremium: number;
                maxPremium: number;
                avgPremium: number;
            };
            coverageRanges: {
                minAnnualLimit: number;
                maxAnnualLimit: number;
                minDeductible: number;
                maxDeductible: number;
            };
        };
    };
    sort: {
        sortBy: string;
        sortOrder: string;
    };
    aggregations?: {
        totalPlans: number;
        availablePlans: number;
        selectedPlans: number;
        byVendor: Array<{
            vendor: string;
            count: number;
            avgPremium: number;
        }>;
    };
    recommendations?: {
        bestValue: string;
        lowestPrice: string;
        bestCoverage: string;
    };
}
/**
 * Fetch Plans Request DTO
 */
export interface FetchPlansRequest {
    leadId: string;
    lineOfBusiness: LineOfBusiness;
    businessType: string;
    leadData: any;
    forceRefresh?: boolean;
}
/**
 * Select Plans Request DTO
 */
export interface SelectPlansRequest {
    leadId: string;
    planIds: string[];
}
