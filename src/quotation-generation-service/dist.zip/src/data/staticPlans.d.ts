/**
 * Static Plan Data
 * Pre-defined insurance plans for testing and initial deployment
 * RPA integration will replace this in production
 */
import { Plan, Vendor, LineOfBusiness } from '../models/plan';
export declare const STATIC_VENDORS: Omit<Vendor, 'createdAt' | 'updatedAt'>[];
export declare const STATIC_MEDICAL_PLANS: Omit<Plan, 'id' | 'leadId' | 'fetchRequestId' | 'fetchedAt' | 'quotationId'>[];
/**
 * Get static plans for a lead
 */
export declare function getStaticPlansForLead(leadId: string, lineOfBusiness: LineOfBusiness, businessType: string, leadData: any): Plan[];
/**
 * Get vendors by LOB
 */
export declare function getVendorsByLOB(lineOfBusiness: LineOfBusiness): Omit<Vendor, 'createdAt' | 'updatedAt'>[];
