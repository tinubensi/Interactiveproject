/**
 * Authentication utilities - Stub version for local development
 */
import { HttpRequest } from '@azure/functions';
export interface UserContext {
    userId: string;
    email: string;
    role: string;
    permissions: string[];
    name?: string;
}
export declare class AuthError extends Error {
    constructor(message: string);
}
export declare class ForbiddenError extends Error {
    constructor(message: string);
}
export declare function extractUserContext(request: HttpRequest): Promise<UserContext | null>;
export declare function ensureAuthorized(request: HttpRequest): Promise<UserContext>;
export declare function checkPermission(userId: string, permission: string): Promise<boolean>;
export declare function requirePermission(userId: string, permission: string): Promise<void>;
export declare function validateServiceKey(request: HttpRequest): void;
export declare const FORM_PERMISSIONS: {
    readonly FORMS_CREATE: "forms:create";
    readonly FORMS_READ: "forms:read";
    readonly FORMS_UPDATE: "forms:update";
    readonly FORMS_DELETE: "forms:delete";
    readonly FORMS_MANAGE: "forms:manage";
    readonly FORMS_SUBMIT: "forms:submit";
};
export declare const QUOTATION_PERMISSIONS: {
    readonly QUOTATIONS_CREATE: "quotations:create";
    readonly QUOTATIONS_READ: "quotations:read";
    readonly QUOTATIONS_UPDATE: "quotations:update";
    readonly QUOTATIONS_DELETE: "quotations:delete";
};
export declare const CUSTOMER_PERMISSIONS: {
    readonly CUSTOMERS_CREATE: "customers:create";
    readonly CUSTOMERS_READ: "customers:read";
    readonly CUSTOMERS_UPDATE: "customers:update";
    readonly CUSTOMERS_DELETE: "customers:delete";
    readonly ADMIN_DEBUG: "customers:admin:debug";
    readonly POLICIES_READ: "policies:read";
};
export declare const POLICY_PERMISSIONS: {
    readonly POLICIES_CREATE: "policies:create";
    readonly POLICIES_READ: "policies:read";
    readonly POLICIES_UPDATE: "policies:update";
    readonly POLICIES_DELETE: "policies:delete";
    readonly POLICIES_ENDORSE: "policies:endorse";
};
export declare const DOCUMENT_PERMISSIONS: {
    readonly DOCUMENTS_CREATE: "documents:create";
    readonly DOCUMENTS_READ: "documents:read";
    readonly DOCUMENTS_UPDATE: "documents:update";
    readonly DOCUMENTS_DELETE: "documents:delete";
    readonly DOCUMENTS_UPLOAD: "documents:upload";
};
export declare const LEAD_PERMISSIONS: {
    readonly LEADS_CREATE: "leads:create";
    readonly LEADS_READ: "leads:read";
    readonly LEADS_UPDATE: "leads:update";
    readonly LEADS_DELETE: "leads:delete";
};
export declare const QUOTES_PERMISSIONS: {
    readonly QUOTES_READ: "quotes:read";
    readonly QUOTES_CREATE: "quotes:create";
    readonly QUOTES_UPDATE: "quotes:update";
    readonly QUOTES_DELETE: "quotes:delete";
};
export declare const QUOTE_PERMISSIONS: {
    readonly QUOTES_READ: "quotes:read";
    readonly QUOTES_CREATE: "quotes:create";
    readonly QUOTES_UPDATE: "quotes:update";
    readonly QUOTES_DELETE: "quotes:delete";
};
export declare const PIPELINE_PERMISSIONS: {
    readonly PIPELINES_CREATE: "pipelines:create";
    readonly PIPELINES_READ: "pipelines:read";
    readonly PIPELINES_UPDATE: "pipelines:update";
    readonly PIPELINES_DELETE: "pipelines:delete";
    readonly PIPELINES_MANAGE: "pipelines:manage";
    readonly PIPELINES_ACTIVATE: "pipelines:activate";
    readonly INSTANCES_READ: "instances:read";
    readonly INSTANCES_MANAGE: "instances:manage";
    readonly APPROVALS_READ: "approvals:read";
};
