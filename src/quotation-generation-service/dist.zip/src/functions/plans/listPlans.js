"use strict";
/**
 * List Plans Function
 * Lists plans with advanced filtering and pagination
 * Reference: Petli getPlans with filters
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.listPlans = listPlans;
const functions_1 = require("@azure/functions");
const cosmosService_1 = require("../../services/cosmosService");
const corsHelper_1 = require("../../utils/corsHelper");
async function listPlans(request, context) {
    // Handle CORS preflight
    const preflightResponse = (0, corsHelper_1.handlePreflight)(request);
    if (preflightResponse)
        return preflightResponse;
    try {
        const body = await request.json();
        if (!body.leadId) {
            return (0, corsHelper_1.withCors)(request, {
                status: 400,
                jsonBody: {
                    error: 'leadId is required'
                }
            });
        }
        // Set defaults
        const listRequest = {
            leadId: body.leadId,
            page: body.page || 1,
            limit: Math.min(body.limit || 20, 100),
            sortBy: body.sortBy || 'annualPremium',
            sortOrder: body.sortOrder || 'asc',
            filters: body.filters || {},
            applyFilterId: body.applyFilterId
        };
        // If applyFilterId is provided, load saved filter
        if (listRequest.applyFilterId) {
            const savedFilter = await cosmosService_1.cosmosService.getFilter(body.leadId);
            if (savedFilter) {
                listRequest.filters = {
                    ...listRequest.filters,
                    annualPremium: savedFilter.annualPremium,
                    monthlyPremium: savedFilter.monthlyPremium,
                    annualLimit: savedFilter.annualLimit,
                    deductible: savedFilter.deductible,
                    coInsurance: savedFilter.coInsurance,
                    waitingPeriod: savedFilter.waitingPeriod,
                    vendorIds: savedFilter.selectedVendors
                };
            }
        }
        // Query Cosmos DB
        const result = await cosmosService_1.cosmosService.listPlans(listRequest);
        // Calculate aggregations
        const allPlans = await cosmosService_1.cosmosService.getPlansForLead(body.leadId);
        result.aggregations = {
            totalPlans: allPlans.length,
            availablePlans: allPlans.filter(p => p.isAvailable).length,
            selectedPlans: allPlans.filter(p => p.isSelected).length,
            byVendor: Array.from(new Set(allPlans.map(p => p.vendorName))).map(vendor => ({
                vendor,
                count: allPlans.filter(p => p.vendorName === vendor).length,
                avgPremium: allPlans.filter(p => p.vendorName === vendor).reduce((sum, p) => sum + p.annualPremium, 0) / allPlans.filter(p => p.vendorName === vendor).length
            }))
        };
        // Calculate recommendations
        const sortedByPrice = [...result.data].sort((a, b) => a.annualPremium - b.annualPremium);
        const sortedByCoverage = [...result.data].sort((a, b) => b.annualLimit - a.annualLimit);
        const recommended = result.data.find(p => p.isRecommended);
        result.recommendations = {
            bestValue: recommended?.id || sortedByPrice[0]?.id || '',
            lowestPrice: sortedByPrice[0]?.id || '',
            bestCoverage: sortedByCoverage[0]?.id || ''
        };
        context.log(`Listed ${result.data.length} plans for lead ${body.leadId}`);
        return (0, corsHelper_1.withCors)(request, {
            status: 200,
            jsonBody: {
                success: true,
                ...result
            }
        });
    }
    catch (error) {
        context.error('List plans error:', error);
        return (0, corsHelper_1.withCors)(request, {
            status: 500,
            jsonBody: {
                success: false,
                error: 'Failed to list plans',
                details: error.message
            }
        });
    }
}
functions_1.app.http('listPlans', {
    methods: ['POST', 'OPTIONS'],
    authLevel: 'anonymous',
    route: 'plans/list',
    handler: listPlans
});
//# sourceMappingURL=listPlans.js.map