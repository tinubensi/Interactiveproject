"use strict";
/**
 * Get Plan by ID Function
 * Retrieves a single plan by ID
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPlanById = getPlanById;
const functions_1 = require("@azure/functions");
const cosmosService_1 = require("../../services/cosmosService");
async function getPlanById(request, context) {
    try {
        const id = request.params.id;
        const leadId = request.query.get('leadId');
        if (!id) {
            return {
                status: 400,
                jsonBody: {
                    error: 'Plan ID is required'
                }
            };
        }
        if (!leadId) {
            return {
                status: 400,
                jsonBody: {
                    error: 'leadId query parameter is required'
                }
            };
        }
        const plan = await cosmosService_1.cosmosService.getPlanById(id, leadId);
        if (!plan) {
            return {
                status: 404,
                jsonBody: {
                    error: 'Plan not found'
                }
            };
        }
        context.log(`Retrieved plan: ${plan.planName}`);
        return {
            status: 200,
            jsonBody: {
                success: true,
                data: {
                    plan
                }
            }
        };
    }
    catch (error) {
        context.error('Get plan by ID error:', error);
        return {
            status: 500,
            jsonBody: {
                success: false,
                error: 'Failed to retrieve plan',
                details: error.message
            }
        };
    }
}
functions_1.app.http('getPlanById', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'plans/{id}',
    handler: getPlanById
});
//# sourceMappingURL=getPlanById.js.map