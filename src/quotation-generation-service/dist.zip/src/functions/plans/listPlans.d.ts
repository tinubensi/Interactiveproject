/**
 * List Plans Function
 * Lists plans with advanced filtering and pagination
 * Reference: Petli getPlans with filters
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function listPlans(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
