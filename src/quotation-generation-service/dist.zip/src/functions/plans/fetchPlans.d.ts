/**
 * Fetch Plans Function
 * Triggers plan fetching from vendors for a lead
 * Reference: Petli getPlans logic
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function fetchPlans(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
