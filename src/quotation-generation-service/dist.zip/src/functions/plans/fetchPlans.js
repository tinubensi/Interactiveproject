"use strict";
/**
 * Fetch Plans Function
 * Triggers plan fetching from vendors for a lead
 * Reference: Petli getPlans logic
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchPlans = fetchPlans;
const functions_1 = require("@azure/functions");
const uuid_1 = require("uuid");
const cosmosService_1 = require("../../services/cosmosService");
const eventGridService_1 = require("../../services/eventGridService");
const planFetchingService_1 = require("../../services/planFetchingService");
const corsHelper_1 = require("../../utils/corsHelper");
async function fetchPlans(request, context) {
    // Handle CORS preflight
    const preflightResponse = (0, corsHelper_1.handlePreflight)(request);
    if (preflightResponse)
        return preflightResponse;
    try {
        const body = await request.json();
        if (!body.leadId || !body.lineOfBusiness) {
            return (0, corsHelper_1.withCors)(request, {
                status: 400,
                jsonBody: {
                    error: 'leadId and lineOfBusiness are required'
                }
            });
        }
        // Check if plans already exist for this lead
        const existingPlans = await cosmosService_1.cosmosService.getPlansForLead(body.leadId);
        if (existingPlans.length > 0 && !body.forceRefresh) {
            return (0, corsHelper_1.withCors)(request, {
                status: 200,
                jsonBody: {
                    success: true,
                    message: 'Plans already fetched for this lead',
                    data: {
                        plans: existingPlans,
                        totalPlans: existingPlans.length,
                        cached: true
                    }
                }
            });
        }
        // If forceRefresh is true and plans exist, delete them first
        if (body.forceRefresh && existingPlans.length > 0) {
            context.log(`Force refresh requested - deleting ${existingPlans.length} existing plans`);
            await cosmosService_1.cosmosService.deletePlansForLead(body.leadId);
        }
        // Create fetch request
        const fetchRequest = {
            id: (0, uuid_1.v4)(),
            leadId: body.leadId,
            lineOfBusiness: body.lineOfBusiness,
            businessType: body.businessType,
            leadData: body.leadData,
            status: 'fetching',
            totalVendors: 0,
            successfulVendors: [],
            failedVendors: [],
            unavailableVendors: [],
            totalPlansFound: 0,
            createdAt: new Date(),
            startedAt: new Date()
        };
        await cosmosService_1.cosmosService.createFetchRequest(fetchRequest);
        // Get vendors for this LOB
        const vendors = await cosmosService_1.cosmosService.getVendorsByLOB(body.lineOfBusiness);
        // Publish fetch started event
        try {
            await eventGridService_1.eventGridService.publishPlansFetchStarted({
                leadId: body.leadId,
                fetchRequestId: fetchRequest.id,
                lineOfBusiness: body.lineOfBusiness,
                vendorCount: vendors.length
            });
        }
        catch (eventError) {
            context.warn('Event Grid not available, continuing without event publishing:', eventError);
        }
        // Fetch plans
        const { plans, successfulVendors, failedVendors } = await planFetchingService_1.planFetchingService.fetchPlansForLead({
            leadId: body.leadId,
            lineOfBusiness: body.lineOfBusiness,
            businessType: body.businessType,
            leadData: body.leadData,
            fetchRequestId: fetchRequest.id
        });
        // Save plans to database
        await cosmosService_1.cosmosService.createPlans(plans);
        // Mark recommended plan
        const recommendedPlan = planFetchingService_1.planFetchingService.calculateRecommendedPlan(plans);
        if (recommendedPlan) {
            await cosmosService_1.cosmosService.updatePlan(recommendedPlan.id, body.leadId, { isRecommended: true });
        }
        // Update fetch request status
        await cosmosService_1.cosmosService.updateFetchRequest(fetchRequest.id, body.leadId, {
            status: 'completed',
            totalVendors: vendors.length,
            successfulVendors,
            failedVendors,
            totalPlansFound: plans.length,
            completedAt: new Date()
        });
        // Publish plans.fetch_completed event to Event Grid (primary communication method)
        let eventPublished = false;
        try {
            await eventGridService_1.eventGridService.publishPlansFetchCompleted({
                leadId: body.leadId,
                fetchRequestId: fetchRequest.id,
                totalPlans: plans.length,
                successfulVendors,
                failedVendors,
                plans // Include full plans array for Lead Service
            });
            eventPublished = true;
            context.log('plans.fetch_completed event published successfully to Event Grid');
        }
        catch (eventError) {
            context.warn('Failed to publish plans.fetch_completed event to Event Grid:', eventError.message);
            // HTTP Fallback: Only call Lead Service directly if Event Grid fails
            // This ensures plans are saved even if Event Grid is unavailable
            try {
                const leadServiceUrl = process.env.LEAD_SERVICE_URL || 'http://localhost:7078/api';
                context.log(`Event Grid failed, using HTTP fallback to save plans at ${leadServiceUrl}/leads/${body.leadId}/save-plans`);
                const response = await fetch(`${leadServiceUrl}/leads/${body.leadId}/save-plans`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        leadId: body.leadId,
                        fetchRequestId: fetchRequest.id,
                        totalPlans: plans.length,
                        successfulVendors,
                        failedVendors,
                        plans
                    })
                });
                if (!response.ok) {
                    const errorText = await response.text();
                    context.warn(`Failed to save plans to Lead Service via HTTP fallback: ${response.status} - ${errorText}`);
                }
                else {
                    context.log('Plans saved to Lead Service via HTTP fallback successfully');
                }
            }
            catch (httpError) {
                context.error('HTTP fallback to Lead Service also failed:', httpError.message);
            }
        }
        context.log(`Plans fetched successfully for lead ${body.leadId}: ${plans.length} plans from ${successfulVendors.length} vendors`);
        return (0, corsHelper_1.withCors)(request, {
            status: 200,
            jsonBody: {
                success: true,
                message: 'Plans fetched successfully',
                data: {
                    fetchRequestId: fetchRequest.id,
                    totalPlans: plans.length,
                    vendors: successfulVendors,
                    plans,
                    recommendedPlanId: recommendedPlan?.id
                }
            }
        });
    }
    catch (error) {
        context.error('Fetch plans error:', error);
        return (0, corsHelper_1.withCors)(request, {
            status: 500,
            jsonBody: {
                success: false,
                error: 'Failed to fetch plans',
                details: error.message
            }
        });
    }
}
functions_1.app.http('fetchPlans', {
    methods: ['POST', 'OPTIONS'],
    authLevel: 'anonymous',
    route: 'plans/fetch',
    handler: fetchPlans
});
//# sourceMappingURL=fetchPlans.js.map