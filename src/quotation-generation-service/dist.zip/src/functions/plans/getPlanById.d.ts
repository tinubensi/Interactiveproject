/**
 * Get Plan by ID Function
 * Retrieves a single plan by ID
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function getPlanById(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
