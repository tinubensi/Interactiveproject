/**
 * Select Plans Function
 * Marks plans as selected for quotation generation
 * Reference: Petli plan selection for quotation
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function selectPlans(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
