"use strict";
/**
 * Get Filters Function
 * Retrieves saved filter criteria for a lead
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFilters = getFilters;
const functions_1 = require("@azure/functions");
const cosmosService_1 = require("../../services/cosmosService");
async function getFilters(request, context) {
    try {
        const leadId = request.params.leadId;
        if (!leadId) {
            return {
                status: 400,
                jsonBody: {
                    error: 'leadId is required'
                }
            };
        }
        const filter = await cosmosService_1.cosmosService.getFilter(leadId);
        if (!filter) {
            return {
                status: 404,
                jsonBody: {
                    error: 'No filters found for this lead'
                }
            };
        }
        context.log(`Retrieved filters for lead ${leadId}`);
        return {
            status: 200,
            jsonBody: {
                success: true,
                data: {
                    filter
                }
            }
        };
    }
    catch (error) {
        context.error('Get filters error:', error);
        return {
            status: 500,
            jsonBody: {
                success: false,
                error: 'Failed to retrieve filters',
                details: error.message
            }
        };
    }
}
functions_1.app.http('getFilters', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'plans/filters/{leadId}',
    handler: getFilters
});
//# sourceMappingURL=getFilters.js.map