/**
 * Get Filters Function
 * Retrieves saved filter criteria for a lead
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function getFilters(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
