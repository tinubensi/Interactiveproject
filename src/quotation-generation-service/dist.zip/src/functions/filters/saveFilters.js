"use strict";
/**
 * Save Filters Function
 * Saves user-defined filter criteria for plans
 * Reference: Petli savePlanFilters
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveFilters = saveFilters;
const functions_1 = require("@azure/functions");
const uuid_1 = require("uuid");
const cosmosService_1 = require("../../services/cosmosService");
const eventGridService_1 = require("../../services/eventGridService");
async function saveFilters(request, context) {
    try {
        const body = await request.json();
        if (!body.leadId) {
            return {
                status: 400,
                jsonBody: {
                    error: 'leadId is required'
                }
            };
        }
        // Check if filter exists for this lead
        const existingFilter = await cosmosService_1.cosmosService.getFilter(body.leadId);
        const filter = {
            id: existingFilter?.id || (0, uuid_1.v4)(),
            leadId: body.leadId,
            annualPremium: body.annualPremium,
            monthlyPremium: body.monthlyPremium,
            annualLimit: body.annualLimit,
            deductible: body.deductible,
            coInsurance: body.coInsurance,
            waitingPeriod: body.waitingPeriod,
            selectedVendors: body.selectedVendors,
            excludedVendors: body.excludedVendors,
            planTypes: body.planTypes,
            requiredBenefits: body.requiredBenefits,
            excludedBenefits: body.excludedBenefits,
            createdAt: existingFilter?.createdAt || new Date(),
            updatedAt: new Date()
        };
        const savedFilter = await cosmosService_1.cosmosService.saveFilter(filter);
        // Get filtered plans count
        const allPlans = await cosmosService_1.cosmosService.getPlansForLead(body.leadId);
        const filteredPlans = applyFiltersToPlans(allPlans, savedFilter);
        // Publish event
        await eventGridService_1.eventGridService.publishPlansFiltered({
            leadId: body.leadId,
            filterCriteria: savedFilter,
            resultCount: filteredPlans.length
        });
        context.log(`Filters saved for lead ${body.leadId}, ${filteredPlans.length} plans match`);
        return {
            status: 200,
            jsonBody: {
                success: true,
                message: 'Filters saved successfully',
                data: {
                    filter: savedFilter,
                    matchingPlansCount: filteredPlans.length
                }
            }
        };
    }
    catch (error) {
        context.error('Save filters error:', error);
        return {
            status: 500,
            jsonBody: {
                success: false,
                error: 'Failed to save filters',
                details: error.message
            }
        };
    }
}
function applyFiltersToPlans(plans, filter) {
    return plans.filter(plan => {
        if (filter.annualPremium) {
            if (filter.annualPremium.min && plan.annualPremium < filter.annualPremium.min)
                return false;
            if (filter.annualPremium.max && plan.annualPremium > filter.annualPremium.max)
                return false;
        }
        if (filter.deductible) {
            if (filter.deductible.min && plan.deductible < filter.deductible.min)
                return false;
            if (filter.deductible.max && plan.deductible > filter.deductible.max)
                return false;
        }
        if (filter.annualLimit) {
            if (filter.annualLimit.min && plan.annualLimit < filter.annualLimit.min)
                return false;
            if (filter.annualLimit.max && plan.annualLimit > filter.annualLimit.max)
                return false;
        }
        if (filter.selectedVendors && filter.selectedVendors.length > 0) {
            if (!filter.selectedVendors.includes(plan.vendorId))
                return false;
        }
        return true;
    });
}
functions_1.app.http('saveFilters', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'plans/filters',
    handler: saveFilters
});
//# sourceMappingURL=saveFilters.js.map