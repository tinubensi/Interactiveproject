/**
 * Save Filters Function
 * Saves user-defined filter criteria for plans
 * Reference: Petli savePlanFilters
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function saveFilters(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
