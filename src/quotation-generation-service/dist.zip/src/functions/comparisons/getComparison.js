"use strict";
/**
 * Get Comparison Function
 * Retrieves plan comparison by ID or for a lead
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getComparison = getComparison;
const functions_1 = require("@azure/functions");
const cosmosService_1 = require("../../services/cosmosService");
async function getComparison(request, context) {
    try {
        const leadId = request.query.get('leadId');
        if (!leadId) {
            return {
                status: 400,
                jsonBody: {
                    error: 'leadId query parameter is required'
                }
            };
        }
        const comparison = await cosmosService_1.cosmosService.getComparisonForLead(leadId);
        if (!comparison) {
            return {
                status: 404,
                jsonBody: {
                    error: 'No comparison found for this lead'
                }
            };
        }
        // Fetch the actual plans
        const plans = await Promise.all(comparison.planIds.map(id => cosmosService_1.cosmosService.getPlanById(id, leadId)));
        context.log(`Retrieved comparison for lead ${leadId}`);
        return {
            status: 200,
            jsonBody: {
                success: true,
                data: {
                    comparison,
                    plans: plans.filter(p => p !== null)
                }
            }
        };
    }
    catch (error) {
        context.error('Get comparison error:', error);
        return {
            status: 500,
            jsonBody: {
                success: false,
                error: 'Failed to retrieve comparison',
                details: error.message
            }
        };
    }
}
functions_1.app.http('getComparison', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'plans/compare',
    handler: getComparison
});
//# sourceMappingURL=getComparison.js.map