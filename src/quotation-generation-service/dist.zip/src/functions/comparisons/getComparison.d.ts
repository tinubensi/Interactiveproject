/**
 * Get Comparison Function
 * Retrieves plan comparison by ID or for a lead
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function getComparison(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
