/**
 * Create Comparison Function
 * Creates a side-by-side comparison of selected plans
 * Reference: Petli generateComparison
 */
import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function createComparison(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
