"use strict";
/**
 * Handle Lead Created Event
 * Auto-triggers plan fetching when a lead is created
 * Listens to lead.created event from Lead Service
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleLeadCreated = handleLeadCreated;
const functions_1 = require("@azure/functions");
const uuid_1 = require("uuid");
const cosmosService_1 = require("../../services/cosmosService");
const eventGridService_1 = require("../../services/eventGridService");
const planFetchingService_1 = require("../../services/planFetchingService");
async function handleLeadCreated(eventGridEvent, context) {
    try {
        const event = eventGridEvent;
        const data = event.data;
        context.log(`Received lead.created event for lead ${data.leadId}`);
        // Create fetch request
        const fetchRequest = {
            id: (0, uuid_1.v4)(),
            leadId: data.leadId,
            lineOfBusiness: data.lineOfBusiness,
            businessType: data.businessType,
            leadData: data.lobData,
            status: 'fetching',
            totalVendors: 0,
            successfulVendors: [],
            failedVendors: [],
            unavailableVendors: [],
            totalPlansFound: 0,
            createdAt: new Date(),
            startedAt: new Date()
        };
        await cosmosService_1.cosmosService.createFetchRequest(fetchRequest);
        // Get vendors
        const vendors = await cosmosService_1.cosmosService.getVendorsByLOB(data.lineOfBusiness);
        // Publish fetch started event
        await eventGridService_1.eventGridService.publishPlansFetchStarted({
            leadId: data.leadId,
            fetchRequestId: fetchRequest.id,
            lineOfBusiness: data.lineOfBusiness,
            vendorCount: vendors.length
        });
        // Fetch plans
        const { plans, successfulVendors, failedVendors } = await planFetchingService_1.planFetchingService.fetchPlansForLead({
            leadId: data.leadId,
            lineOfBusiness: data.lineOfBusiness,
            businessType: data.businessType,
            leadData: data.lobData,
            fetchRequestId: fetchRequest.id
        });
        // Save plans
        await cosmosService_1.cosmosService.createPlans(plans);
        // Mark recommended plan
        const recommendedPlan = planFetchingService_1.planFetchingService.calculateRecommendedPlan(plans);
        if (recommendedPlan) {
            await cosmosService_1.cosmosService.updatePlan(recommendedPlan.id, data.leadId, { isRecommended: true });
        }
        // Update fetch request
        await cosmosService_1.cosmosService.updateFetchRequest(fetchRequest.id, data.leadId, {
            status: 'completed',
            totalVendors: vendors.length,
            successfulVendors,
            failedVendors,
            totalPlansFound: plans.length,
            completedAt: new Date()
        });
        // Publish fetch completed event with plans for Lead Service to save
        await eventGridService_1.eventGridService.publishPlansFetchCompleted({
            leadId: data.leadId,
            fetchRequestId: fetchRequest.id,
            totalPlans: plans.length,
            successfulVendors,
            failedVendors,
            plans // Include full plans array for Lead Service
        });
        context.log(`Auto-fetched ${plans.length} plans for lead ${data.leadId}`);
    }
    catch (error) {
        context.error('Handle lead created error:', error);
    }
}
functions_1.app.eventGrid('handleLeadCreated', {
    handler: handleLeadCreated
});
//# sourceMappingURL=handleLeadCreated.js.map