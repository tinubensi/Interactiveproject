/**
 * Handle Lead Created Event
 * Auto-triggers plan fetching when a lead is created
 * Listens to lead.created event from Lead Service
 */
import { InvocationContext } from '@azure/functions';
export declare function handleLeadCreated(eventGridEvent: any, context: InvocationContext): Promise<void>;
