"use strict";
/**
 * Quotation Generation Service
 * Azure Functions Entry Point
 *
 * This service handles:
 * - Fetching insurance plans from vendors
 * - Plan filtering and comparison
 * - Plan selection for quotation
 */
Object.defineProperty(exports, "__esModule", { value: true });
// Import all HTTP functions
require("./functions/plans/fetchPlans");
require("./functions/plans/listPlans");
require("./functions/plans/getPlanById");
require("./functions/plans/selectPlans");
require("./functions/filters/saveFilters");
require("./functions/filters/getFilters");
require("./functions/comparisons/createComparison");
require("./functions/comparisons/getComparison");
require("./functions/vendors/getVendors");
// Import all event handlers
require("./functions/events/handleLeadCreated");
console.log('Quotation Generation Service loaded');
//# sourceMappingURL=index.js.map