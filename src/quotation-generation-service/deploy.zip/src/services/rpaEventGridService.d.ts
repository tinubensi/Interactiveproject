/**
 * RPA Event Grid Service
 * Publishes RPA request events to Event Grid for direct container job triggering
 */
declare class RPAEventGridService {
    private client;
    private enabled;
    private endpoint;
    constructor();
    /**
     * Publish an RPA request event for a specific vendor
     */
    publishRPARequest(params: {
        leadId: string;
        vendorId: string;
        leadData: any;
    }): Promise<boolean>;
    /**
     * Publish RPA request events for multiple vendors
     */
    publishMultipleRequests(params: {
        leadId: string;
        leadData: any;
        vendorIds: string[];
    }): Promise<{
        success: number;
        failed: number;
    }>;
    /**
     * Check if RPA Event Grid is enabled
     */
    isEnabled(): boolean;
    /**
     * Get endpoint information (for debugging)
     */
    getEndpoint(): string;
}
export declare const rpaEventGridService: RPAEventGridService;
export {};
