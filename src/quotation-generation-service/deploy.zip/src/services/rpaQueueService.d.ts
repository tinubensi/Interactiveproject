/**
 * RPA Queue Service
 * Queues RPA jobs to Azure Storage Queue for container job execution
 */
declare class RPAQueueService {
    private queueClient;
    private enabled;
    constructor();
    /**
     * Queue an RPA job for plan fetching
     */
    queuePlanFetchJob(params: {
        leadId: string;
        lineOfBusiness: string;
        businessType: string;
        leadData: any;
        vendorId?: string;
        fetchRequestId?: string;
    }): Promise<boolean>;
    /**
     * Queue RPA jobs for multiple vendors
     */
    queueMultipleJobs(params: {
        leadId: string;
        lineOfBusiness: string;
        businessType: string;
        leadData: any;
        vendorIds: string[];
        fetchRequestId?: string;
    }): Promise<{
        success: number;
        failed: number;
    }>;
    /**
     * Check if RPA queue is enabled
     */
    isEnabled(): boolean;
}
export declare const rpaQueueService: RPAQueueService;
export {};
