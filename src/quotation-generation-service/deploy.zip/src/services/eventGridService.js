"use strict";
/**
 * Event Grid Service for Quotation Generation
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventGridService = void 0;
const eventgrid_1 = require("@azure/eventgrid");
const uuid_1 = require("uuid");
class EventGridService {
    client;
    topicEndpoint;
    enabled;
    constructor() {
        this.topicEndpoint = process.env.EVENT_GRID_TOPIC_ENDPOINT || '';
        const topicKey = process.env.EVENT_GRID_TOPIC_KEY || '';
        console.log(`[Event Grid] Initializing... Endpoint: ${this.topicEndpoint ? 'Set' : 'Missing'}, Key: ${topicKey ? 'Set' : 'Missing'}`);
        // Only initialize if endpoint is configured
        if (this.topicEndpoint && topicKey) {
            try {
                // Allow insecure connection for localhost development
                const clientOptions = this.topicEndpoint.includes('localhost') || this.topicEndpoint.includes('127.0.0.1')
                    ? { allowInsecureConnection: true }
                    : undefined;
                this.client = new eventgrid_1.EventGridPublisherClient(this.topicEndpoint, 'EventGrid', new eventgrid_1.AzureKeyCredential(topicKey), clientOptions);
                this.enabled = true;
                console.log(`✅ Event Grid client initialized successfully. Endpoint: ${this.topicEndpoint}`);
            }
            catch (error) {
                console.error('❌ Event Grid initialization failed:', error);
                this.client = null;
                this.enabled = false;
            }
        }
        else {
            console.warn(`⚠️  Event Grid not configured - Endpoint: ${this.topicEndpoint || 'MISSING'}, Key: ${topicKey ? 'Set' : 'MISSING'}`);
            this.client = null;
            this.enabled = false;
        }
    }
    async publishEvent(eventType, subject, data, dataVersion = '1.0') {
        if (!this.enabled || !this.client) {
            const errorMsg = `Event Grid not enabled or client not initialized. Cannot publish ${eventType} for ${subject}`;
            console.warn(`[EVENT GRID DISABLED] ${errorMsg}`);
            // Throw error to trigger HTTP fallback
            throw new Error(errorMsg);
        }
        try {
            const event = {
                id: (0, uuid_1.v4)(),
                eventType,
                subject,
                eventTime: new Date().toISOString(),
                data,
                dataVersion
            };
            await this.client.send([event]);
            console.log(`✅ Event published successfully: ${eventType} for ${subject}`);
        }
        catch (error) {
            console.error(`❌ Failed to publish event ${eventType} for ${subject}:`, error);
            throw error;
        }
    }
    // ==================== SPECIFIC EVENTS ====================
    async publishPlansFetchStarted(data) {
        await this.publishEvent('plans.fetch_started', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansFetchCompleted(data) {
        await this.publishEvent('plans.fetch_completed', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansFetchFailed(data) {
        await this.publishEvent('plans.fetch_failed', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansFiltered(data) {
        await this.publishEvent('plans.filtered', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansCompared(data) {
        await this.publishEvent('plans.compared', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
    async publishPlansSelected(data) {
        await this.publishEvent('plans.selected', `plans/${data.leadId}`, {
            ...data,
            timestamp: new Date()
        });
    }
}
exports.eventGridService = new EventGridService();
//# sourceMappingURL=eventGridService.js.map