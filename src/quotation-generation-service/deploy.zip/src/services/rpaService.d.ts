/**
 * RPA Service
 * Triggers RPA bots to fetch plans from insurance portals
 */
export declare class RPAService {
    private rpaUrl;
    private rpaKey;
    constructor();
    /**
     * Trigger RPA to fetch plans for a lead
     *
     * @param leadData - Lead information including LOB, contact details, etc.
     * @returns Success status and triggered vendor count
     */
    triggerRPA(leadData: {
        leadId: string;
        lineOfBusiness: string;
        businessType?: string;
        firstName?: string;
        lastName?: string;
        email?: string;
        phone?: any;
        emirate?: string;
        lobData?: any;
        [key: string]: any;
    }): Promise<{
        success: boolean;
        vendorsTriggered: string[];
        vendorsFailed: any[];
        error?: string;
    }>;
    /**
     * Wait for RPA to complete by polling the database
     *
     * @param leadId - Lead ID to check for plans
     * @param maxWaitSeconds - Maximum time to wait in seconds
     * @param pollIntervalSeconds - How often to check in seconds
     * @returns Number of plans found
     */
    waitForRPACompletion(leadId: string, checkPlansExist: () => Promise<number>, maxWaitSeconds?: number, pollIntervalSeconds?: number): Promise<number>;
}
export declare const rpaService: RPAService;
