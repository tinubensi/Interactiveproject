/**
 * Plan Fetching Service
 * Fetches insurance plans from Cosmos DB (lead-service-db/plans)
 * Plans are automatically fetched by RPA when leads are created
 */
import { Plan, LineOfBusiness } from '../models/plan';
declare class PlanFetchingService {
    private leadsDBCosmosClient;
    /**
     * Get Cosmos client for lead-service-db (where RPA saves plans)
     */
    private getLeadsDBClient;
    /**
     * Fetch plans for a lead from Cosmos DB (lead-service-db/plans)
     * Plans are fetched by RPA bots from real insurance portals
     * NO STATIC PLANS - Only real plans from vendors
     */
    fetchPlansForLead(params: {
        leadId: string;
        lineOfBusiness: LineOfBusiness;
        businessType: string;
        leadData: any;
        fetchRequestId: string;
    }): Promise<{
        plans: Plan[];
        successfulVendors: string[];
        failedVendors: string[];
    }>;
    /**
     * Fetch plans from Cosmos DB lead-service-db/plans container
     * Plans are automatically saved here by RPA containers when leads are created
     */
    fetchPlansFromCosmosDB(leadId: string, fetchRequestId: string): Promise<{
        plans: Plan[];
        successfulVendors: string[];
        failedVendors: string[];
    }>;
    /**
     * Transform StandardPlan from Cosmos DB to Plan model
     */
    private transformStandardPlanToPlan;
    /**
     * Parse waiting period from various formats
     */
    private parseWaitingPeriod;
    /**
     * Transform benefits to structured format
     * Handles both array format (legacy) and structured format (StandardPlan)
     */
    private transformBenefits;
    /**
     * Calculate recommended plan based on criteria
     */
    calculateRecommendedPlan(plans: Plan[]): Plan | null;
}
export declare const planFetchingService: PlanFetchingService;
export {};
