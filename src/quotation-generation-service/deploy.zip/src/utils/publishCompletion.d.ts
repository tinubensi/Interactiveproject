/**
 * Service Completion Event Publisher
 * DRY utility for publishing service completion events to Event Grid
 */
export interface CompletionParams {
    instanceId: string;
    leadId: string;
    actionCompleted: string;
    serviceName: string;
    correlationId: string;
    status: 'success' | 'failure';
    result?: Record<string, any>;
    error?: {
        code: string;
        message: string;
        retryable: boolean;
    };
}
/**
 * Publish service completion event to Event Grid
 * Event format: service.{actionCompleted}.completed or service.{actionCompleted}.failed
 */
export declare function publishServiceCompletion(params: CompletionParams): Promise<void>;
