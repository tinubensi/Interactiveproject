/**
 * HTTP Fallback utility for pipeline events
 * Calls pipeline service directly if Event Grid fails
 */
export declare function notifyPipelineService(eventType: string, eventData: {
    leadId: string;
    lineOfBusiness?: string;
    [key: string]: unknown;
}, context?: {
    log?: (...args: unknown[]) => void;
}): Promise<void>;
