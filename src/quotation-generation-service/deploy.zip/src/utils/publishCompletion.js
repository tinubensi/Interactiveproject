"use strict";
/**
 * Service Completion Event Publisher
 * DRY utility for publishing service completion events to Event Grid
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.publishServiceCompletion = publishServiceCompletion;
const eventGridService_1 = require("../services/eventGridService");
/**
 * Publish service completion event to Event Grid
 * Event format: service.{actionCompleted}.completed or service.{actionCompleted}.failed
 */
async function publishServiceCompletion(params) {
    const eventType = params.status === 'success'
        ? `service.${params.actionCompleted}.completed`
        : `service.${params.actionCompleted}.failed`;
    await eventGridService_1.eventGridService.publishEvent(eventType, `/${params.serviceName}/${params.leadId}/completion`, {
        instanceId: params.instanceId,
        leadId: params.leadId,
        actionCompleted: params.actionCompleted,
        status: params.status,
        result: params.result || {},
        error: params.error,
        metadata: {
            correlationId: params.correlationId,
            timestamp: new Date().toISOString(),
            serviceName: params.serviceName,
        },
    }, '2.0');
}
//# sourceMappingURL=publishCompletion.js.map