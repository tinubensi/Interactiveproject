/**
 * Pipeline Action Handler Tests - Quotation Generation Service
 * Tests for fetch_plans action handler
 */
export {};
