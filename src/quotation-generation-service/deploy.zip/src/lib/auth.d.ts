/**
 * Authentication utilities for Quotation Generation Service
 * TODO: Implement real authentication when auth service is ready
 */
import { HttpRequest } from '@azure/functions';
export interface UserContext {
    userId: string;
    email: string;
    name?: string;
    roles: string[];
    permissions?: string[];
    azureAdGroups?: string[];
    organizationId?: string;
    sessionId?: string;
    authMethod?: 'b2b_sso' | 'b2c_password' | 'b2c_otp';
    territories?: string[];
    teamId?: string;
}
export declare class AuthError extends Error {
    constructor(message?: string);
}
export declare class ForbiddenError extends Error {
    permission?: string | undefined;
    constructor(message?: string, permission?: string | undefined);
}
/**
 * Ensure request is authorized - throws if not authenticated
 */
export declare function ensureAuthorized(request: HttpRequest): Promise<UserContext>;
/**
 * Require a specific permission - throws ForbiddenError if not authorized
 */
export declare function requirePermission(userId: string, permission: string): Promise<void>;
/**
 * Validate internal service key for event handlers
 */
export declare function validateServiceKey(request: HttpRequest): boolean;
/**
 * Permission constants for quote generation operations
 */
export declare const QUOTE_PERMISSIONS: {
    readonly QUOTES_CREATE: "quotes:create";
    readonly QUOTES_READ: "quotes:read";
};
