"use strict";
/**
 * Fetch Plans Function
 * Triggers plan fetching from vendors for a lead
 * Reference: Petli getPlans logic
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchPlans = fetchPlans;
const functions_1 = require("@azure/functions");
const uuid_1 = require("uuid");
const cosmosService_1 = require("../../services/cosmosService");
const eventGridService_1 = require("../../services/eventGridService");
const rpaQueueService_1 = require("../../services/rpaQueueService");
const rpaEventGridService_1 = require("../../services/rpaEventGridService");
const auth_1 = require("../../lib/auth");
const corsHelper_1 = require("../../utils/corsHelper");
const pipelineFallback_1 = require("../../utils/pipelineFallback");
async function fetchPlans(request, context) {
    // Handle CORS preflight
    const preflightResponse = (0, corsHelper_1.handlePreflight)(request);
    if (preflightResponse)
        return preflightResponse;
    try {
        // CRITICAL FIX: Allow service key authentication for internal service calls
        // This allows Pipeline Service to trigger plan fetching without user authentication
        const isServiceCall = (0, auth_1.validateServiceKey)(request);
        if (!isServiceCall) {
            // For user calls, require authentication
            const userContext = await (0, auth_1.ensureAuthorized)(request);
            await (0, auth_1.requirePermission)(userContext.userId, auth_1.QUOTE_PERMISSIONS.QUOTES_CREATE);
        }
        else {
            context.log('Plan fetch request authenticated via service key (internal service call)');
        }
        const body = await request.json();
        if (!body.leadId || !body.lineOfBusiness) {
            return (0, corsHelper_1.withCors)(request, {
                status: 400,
                jsonBody: {
                    error: 'leadId and lineOfBusiness are required'
                }
            });
        }
        // Check if plans already exist for this lead
        const existingPlans = await cosmosService_1.cosmosService.getPlansForLead(body.leadId);
        if (existingPlans.length > 0 && !body.forceRefresh) {
            return (0, corsHelper_1.withCors)(request, {
                status: 200,
                jsonBody: {
                    success: true,
                    message: 'Plans already fetched for this lead',
                    data: {
                        plans: existingPlans,
                        totalPlans: existingPlans.length,
                        cached: true
                    }
                }
            });
        }
        // If forceRefresh is true and plans exist, delete them first
        if (body.forceRefresh && existingPlans.length > 0) {
            context.log(`Force refresh requested - deleting ${existingPlans.length} existing plans`);
            await cosmosService_1.cosmosService.deletePlansForLead(body.leadId);
        }
        // Create fetch request
        const fetchRequest = {
            id: (0, uuid_1.v4)(),
            leadId: body.leadId,
            lineOfBusiness: body.lineOfBusiness,
            businessType: body.businessType,
            leadData: body.leadData,
            status: 'fetching',
            totalVendors: 0,
            successfulVendors: [],
            failedVendors: [],
            unavailableVendors: [],
            totalPlansFound: 0,
            createdAt: new Date(),
            startedAt: new Date()
        };
        await cosmosService_1.cosmosService.createFetchRequest(fetchRequest);
        // Get vendors for this LOB
        const vendors = await cosmosService_1.cosmosService.getVendorsByLOB(body.lineOfBusiness);
        // Publish fetch started event
        let fetchStartedPublished = false;
        try {
            await eventGridService_1.eventGridService.publishPlansFetchStarted({
                leadId: body.leadId,
                fetchRequestId: fetchRequest.id,
                lineOfBusiness: body.lineOfBusiness,
                vendorCount: vendors.length
            });
            fetchStartedPublished = true;
            context.log('plans.fetch_started event published successfully to Event Grid');
        }
        catch (eventError) {
            context.warn('Event Grid not available for plans.fetch_started, using HTTP fallback:', eventError);
        }
        // HTTP Fallback: Also notify pipeline service directly for plans.fetch_started
        if (!fetchStartedPublished) {
            try {
                await (0, pipelineFallback_1.notifyPipelineService)('plans.fetch_started', {
                    leadId: body.leadId,
                    lineOfBusiness: body.lineOfBusiness,
                    businessType: body.businessType,
                    fetchRequestId: fetchRequest.id,
                    vendorCount: vendors.length,
                }, { log: context.log.bind(context) });
                context.log('[HTTP Fallback] Successfully notified pipeline service: plans.fetch_started');
            }
            catch (fallbackError) {
                context.warn(`[HTTP Fallback] Failed to notify pipeline service for plans.fetch_started: ${fallbackError}`);
            }
        }
        else {
            // Even if Event Grid succeeds, also send HTTP fallback as backup
            try {
                await (0, pipelineFallback_1.notifyPipelineService)('plans.fetch_started', {
                    leadId: body.leadId,
                    lineOfBusiness: body.lineOfBusiness,
                    businessType: body.businessType,
                    fetchRequestId: fetchRequest.id,
                    vendorCount: vendors.length,
                }, { log: context.log.bind(context) });
            }
            catch (fallbackError) {
                // Silent fail - Event Grid already published
                context.log(`[HTTP Fallback] Backup notification failed (Event Grid succeeded): ${fallbackError}`);
            }
        }
        // Separate RPA-enabled vendors from static-plan vendors
        const rpaVendors = vendors.filter(v => v.rpaEnabled === true);
        const staticVendors = vendors.filter(v => v.hasStaticPlans === true && v.rpaEnabled !== true);
        context.log(`Vendors breakdown: ${rpaVendors.length} RPA-enabled, ${staticVendors.length} static plans`);
        // Trigger RPA jobs for RPA-enabled vendors only
        const vendorIds = rpaVendors.map(v => v.id);
        if (vendorIds.length === 0) {
            context.log('No RPA-enabled vendors found, skipping RPA triggering');
        }
        else {
            context.log(`Triggering RPA jobs for ${vendorIds.length} RPA-enabled vendor(s)...`);
        }
        // Try Event Grid first (direct triggering with data injection)
        let eventGridSuccessCount = 0;
        let queueFallbackCount = 0;
        if (vendorIds.length > 0) {
            if (rpaEventGridService_1.rpaEventGridService.isEnabled()) {
                context.log('Using Event Grid for RPA triggering (preferred method)...');
                const eventGridResult = await rpaEventGridService_1.rpaEventGridService.publishMultipleRequests({
                    leadId: body.leadId,
                    leadData: body.leadData,
                    vendorIds
                });
                eventGridSuccessCount = eventGridResult.success;
                // For any failed Event Grid publishes, fall back to queue
                if (eventGridResult.failed > 0) {
                    context.warn(`${eventGridResult.failed} Event Grid publishes failed, falling back to queue...`);
                    const failedVendors = vendorIds.slice(eventGridResult.success); // Get vendors that failed
                    const queueResult = await rpaQueueService_1.rpaQueueService.queueMultipleJobs({
                        leadId: body.leadId,
                        lineOfBusiness: body.lineOfBusiness,
                        businessType: body.businessType,
                        leadData: body.leadData,
                        vendorIds: failedVendors
                    });
                    queueFallbackCount = queueResult.success;
                }
                context.log(`RPA jobs triggered: ${eventGridSuccessCount} via Event Grid, ${queueFallbackCount} via Queue fallback`);
            }
            else {
                // Event Grid not configured, use queue as primary method
                context.log('Event Grid not configured, using Queue for RPA triggering...');
                const queueResult = await rpaQueueService_1.rpaQueueService.queueMultipleJobs({
                    leadId: body.leadId,
                    lineOfBusiness: body.lineOfBusiness,
                    businessType: body.businessType,
                    leadData: body.leadData,
                    vendorIds,
                    fetchRequestId: fetchRequest.id
                });
                queueFallbackCount = queueResult.success;
                context.log(`RPA jobs queued: ${queueResult.success} successful, ${queueResult.failed} failed`);
            }
        }
        // EVENT-DRIVEN ARCHITECTURE: Return immediately after queuing RPA jobs
        // RPA container will publish plans.fetch_completed when it finishes
        context.log(`Plan fetching initiated for lead ${body.leadId}`);
        context.log(`  - RPA jobs queued: ${eventGridSuccessCount + queueFallbackCount}`);
        context.log(`  - Static plans available: ${staticVendors.length}`);
        context.log(`RPA will publish plans.fetch_completed event when processing is complete`);
        return (0, corsHelper_1.withCors)(request, {
            status: 202, // Accepted - processing will continue asynchronously
            jsonBody: {
                success: true,
                message: 'Plan fetching started',
                data: {
                    leadId: body.leadId,
                    fetchRequestId: fetchRequest.id,
                    status: 'fetching',
                    rpaJobsQueued: eventGridSuccessCount + queueFallbackCount,
                    staticPlansCount: staticVendors.length
                }
            }
        });
    }
    catch (error) {
        context.error('Fetch plans error:', error);
        return (0, corsHelper_1.withCors)(request, {
            status: 500,
            jsonBody: {
                success: false,
                error: 'Failed to fetch plans',
                details: error.message
            }
        });
    }
}
functions_1.app.http('fetchPlans', {
    methods: ['POST', 'OPTIONS'],
    authLevel: 'anonymous',
    route: 'plans/fetch',
    handler: fetchPlans
});
//# sourceMappingURL=fetchPlans.js.map