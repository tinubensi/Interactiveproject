/**
 * Handle Lead Created Event
 * Auto-triggers RPA to fetch plans from real insurance portals
 * Listens to lead.created event from Lead Service
 */

import { app, InvocationContext } from '@azure/functions';
import { v4 as uuidv4 } from 'uuid';
import { cosmosService } from '../../services/cosmosService';
import { eventGridService } from '../../services/eventGridService';
import { planFetchingService } from '../../services/planFetchingService';
import { rpaService } from '../../services/rpaService';
import { LeadCreatedEvent } from '../../models/events';
import { PlanFetchRequest } from '../../models/plan';

export async function handleLeadCreated(
  eventGridEvent: any,
  context: InvocationContext
): Promise<void> {
  try {
    context.log('Received Event Grid event:', JSON.stringify(eventGridEvent, null, 2));
    
    // Handle both direct event data and wrapped Event Grid event
    let event: LeadCreatedEvent;
    if (eventGridEvent.data && eventGridEvent.eventType) {
      // Event Grid wrapped format
      event = eventGridEvent as LeadCreatedEvent;
    } else if (eventGridEvent.eventType) {
      // Direct Event Grid event
      event = eventGridEvent as LeadCreatedEvent;
    } else {
      // Array of events (Event Grid can send arrays)
      const events = Array.isArray(eventGridEvent) ? eventGridEvent : [eventGridEvent];
      event = events[0] as LeadCreatedEvent;
    }
    
    const data = event.data;

    context.log(`Received lead.created event for lead ${data.leadId}`);

    // Create fetch request
    const fetchRequest: PlanFetchRequest = {
      id: uuidv4(),
      leadId: data.leadId,
      lineOfBusiness: data.lineOfBusiness,
      businessType: data.businessType,
      leadData: data.lobData,
      status: 'fetching',
      totalVendors: 0,
      successfulVendors: [],
      failedVendors: [],
      unavailableVendors: [],
      totalPlansFound: 0,
      createdAt: new Date(),
      startedAt: new Date()
    };

    await cosmosService.createFetchRequest(fetchRequest);

    // Get vendors
    const vendors = await cosmosService.getVendorsByLOB(data.lineOfBusiness);

    // Publish fetch started event
    await eventGridService.publishPlansFetchStarted({
      leadId: data.leadId,
      fetchRequestId: fetchRequest.id,
      lineOfBusiness: data.lineOfBusiness,
      vendorCount: vendors.length
    });

    // 🤖 TRIGGER RPA TO FETCH PLANS FROM REAL PORTALS (Watania, etc.)
    context.log(`🤖 Triggering RPA bots to fetch plans from insurance portals...`);
    
    const rpaResult = await rpaService.triggerRPA({
      leadId: data.leadId,
      lineOfBusiness: data.lineOfBusiness,
      businessType: data.businessType,
      lobData: data.lobData,
      formData: data.formData
    });

    if (!rpaResult.success) {
      context.error(`❌ RPA trigger failed: ${rpaResult.error}`);
      
      // Update fetch request as failed
      await cosmosService.updateFetchRequest(fetchRequest.id, data.leadId, {
        status: 'failed',
        totalVendors: vendors.length,
        failedVendors: ['watania'],
        totalPlansFound: 0,
        completedAt: new Date()
      });
      
      return;
    }

    context.log(`✅ RPA triggered for ${rpaResult.vendorsTriggered.length} vendor(s)`);
    
    // ⏳ WAIT FOR RPA TO COMPLETE (polls database for plans)
    context.log(`⏳ Waiting for RPA bots to complete (max 3 minutes)...`);
    
    const planCount = await rpaService.waitForRPACompletion(
      data.leadId,
      async () => {
        const existingPlans = await cosmosService.getPlansForLead(data.leadId);
        return existingPlans.length;
      },
      180, // 3 minutes max
      10   // Poll every 10 seconds
    );

    if (planCount === 0) {
      context.warn(`⚠️ RPA timeout - no plans found after 3 minutes`);
      
      // Update fetch request as failed (timeout)
      await cosmosService.updateFetchRequest(fetchRequest.id, data.leadId, {
        status: 'failed',
        totalVendors: vendors.length,
        failedVendors: rpaResult.vendorsFailed.map((v: any) => v.vendorId || 'unknown'),
        totalPlansFound: 0,
        completedAt: new Date()
      });
      
      return;
    }

    // 📦 FETCH THE PLANS SAVED BY RPA
    context.log(`📦 Fetching ${planCount} RPA plans from database...`);
    
    const { plans, successfulVendors, failedVendors } = await planFetchingService.fetchPlansForLead({
      leadId: data.leadId,
      lineOfBusiness: data.lineOfBusiness,
      businessType: data.businessType,
      leadData: data.lobData,
      fetchRequestId: fetchRequest.id
    });

    context.log(`✅ Retrieved ${plans.length} plans from ${successfulVendors.length} vendor(s)`);

    // Mark recommended plan
    const recommendedPlan = planFetchingService.calculateRecommendedPlan(plans);
    if (recommendedPlan) {
      await cosmosService.updatePlan(recommendedPlan.id, data.leadId, { isRecommended: true });
      context.log(`⭐ Marked plan "${recommendedPlan.planName}" as recommended`);
    }

    // Update fetch request
    await cosmosService.updateFetchRequest(fetchRequest.id, data.leadId, {
      status: 'completed',
      totalVendors: vendors.length,
      successfulVendors,
      failedVendors,
      totalPlansFound: plans.length,
      completedAt: new Date()
    });

    // Publish fetch completed event with plans for Lead Service
    await eventGridService.publishPlansFetchCompleted({
      leadId: data.leadId,
      fetchRequestId: fetchRequest.id,
      totalPlans: plans.length,
      successfulVendors,
      failedVendors,
      plans // Include full plans array for Lead Service
    });

    context.log(`🎉 Successfully fetched ${plans.length} REAL plans from insurance portals for lead ${data.leadId}`);
  } catch (error: any) {
    context.error('Handle lead created error:', error);
  }
}

app.eventGrid('handleLeadCreated', {
  handler: handleLeadCreated
});


