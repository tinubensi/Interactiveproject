/**
 * Pipeline Action Handler for Quotation Generation Service
 * Handles pipeline.action.fetch_plans events from Pipeline Service
 */
export {};
